from supachat import poll_for_messages, send_message
import threading

def on_new_message(msg):
    print(f"\nNew message from {msg['from_email']}: {msg['content']}")

email = input("Enter your email: ").strip()
threading.Thread(target=poll_for_messages, args=(email, on_new_message), daemon=True).start()

while True:
    cmd = input("Type 'send' or 'exit': ").strip().lower()
    if cmd == 'send':
        to = input("To: ")
        content = input("Message: ")
        if send_message(email, to, content):
            print("✅ Sent")
        else:
            print("❌ Failed")
    elif cmd == 'exit':
        break

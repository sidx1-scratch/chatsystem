import time
import threading
import os
from supabase import create_client, Client
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    raise EnvironmentError("SUPABASE_URL and SUPABASE_KEY must be set in the environment or in a .env file.")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def poll_for_messages(email, on_new_message):
    seen = set()
    while True:
        try:
            response = supabase.from_("messages").select("*").eq("to_email", email).execute()
            if hasattr(response, "error") and response.error is not None:
                print(f"Error polling messages: {response.error}")
            else:
                messages = response.data or []
                for msg in messages:
                    msg_id = msg.get("id")
                    if msg_id not in seen:
                        on_new_message(msg)
                        seen.add(msg_id)
            time.sleep(0.1)
        except Exception as e:
            print(f"Error polling messages: {e}")
            time.sleep(0.5)

def send_message(from_email, to_email, content):
    data = {
        "from_email": from_email,
        "to_email": to_email,
        "content": content,
    }
    response = supabase.from_("messages").insert(data).execute()
    return not (hasattr(response, "error") and response.error is not None)

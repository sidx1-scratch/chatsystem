from setuptools import setup, find_packages

setup(
    name="supachat",
    version="0.1.0",
    description="Simple Supabase-powered terminal chat library",
    author="sidx1",
    author_email="you@example.com",
    packages=find_packages(),
    install_requires=[
        "supabase",
    ],
    python_requires=">=3.6",
)

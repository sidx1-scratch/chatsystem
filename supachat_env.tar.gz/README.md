# SupaChat

A simple Python terminal chat library using Supabase.

## Setup

Create a `.env` file or export these variables:
- `SUPABASE_URL`
- `SUPABASE_KEY`

## Example

```python
from supachat import poll_for_messages, send_message
```

See `examples/run_chat.py` for a working CLI chat.
